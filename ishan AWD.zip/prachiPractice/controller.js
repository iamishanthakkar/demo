const app = angular.module("myApp", []);

app.controller("myCtrl", ($scope, $http) => {
    $scope.persons = [];

    $scope.sortt = "age"

    $scope.sorttt = () => {
        console.log("clicked");
        // $scope.sortt = $scope.sortt === "age" ? "-age" : "age";
        if ($scope.sortt === "age") {
            $scope.sortt = "-age"
            return
        }

        if ($scope.sortt === "-age") {
            $scope.sortt = "age"
            return
        }
    }

    $scope.getAllData = () => {
        $http.get('/api/alldata').then((res) => {
            $scope.persons = res.data;
        })
    }


    $scope.addData = () => {
        $http.post('/api/addRecord', $scope.newPerson).then(() => {
            $scope.getAllData();
        })
    }


    $scope.getAllData();
})