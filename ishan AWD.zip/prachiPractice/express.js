const express = require("express");
const mongoose = require("mongoose");
const app = express();
const DBConnect = require("./db");
DBConnect();

app.use(express.json());
app.use(express.static(__dirname));

const personSchema = mongoose.Schema({
    name:String,
    age:Number,
    city:String
})

const AllPersons = mongoose.model('alldatas',personSchema);

app.get('/',(req,res)=>{
    res.sendFile(__dirname+"/index.html");
})


app.get('/api/alldata', async (req,res)=>{
    const result = await AllPersons.find();
    res.json(result);
});

app.post('/api/addRecord',async (req,res)=>{
    const newPerson = new AllPersons(req.body);
    const result = await newPerson.save();
    if(result){
       res.send();
    }
})

app.listen(8080,()=>console.log("http://localhost:8080"));