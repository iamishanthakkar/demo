const mongoose = require("mongoose");

const url = "mongodb://127.0.0.1:27017/dummy";

const DBConnect =async () =>{
    const conn = mongoose.connect(url);
    if(conn){
        console.log("Db Connected");
    }else{
        console.log("Not Connected");
    }
}

module.exports = DBConnect;